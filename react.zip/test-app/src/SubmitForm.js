import React, { useState } from 'react';
import axios from 'axios';

const SubmitForm = () => {
  const [title, setTitle] = useState('');
  const [comment, setComment] = useState('');
  const [items, setItems] = useState([]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
        const json = JSON.stringify({ 'title':title });
      const response = await axios.post('https://site.test/react/api/add_form.php', json);
      
      console.log('Data Updated!', response.data);
      fetchData();
    } catch (error) {
      console.error('Update failed:', error.message);
    }
  };
  const addComment = async (e) => {
    e.preventDefault();
    try {
        const json = JSON.stringify({
             'uid':e.target.id,
              'comment':comment
            });
      const response = await axios.post('https://site.test/react/api/add_comment.php', json);
      
      console.log('Data Updated!', response.data);
      fetchData();
    } catch (error) {
      console.error('Update failed:', error.message);
    }
  };
  const fetchData = async () => {
    try {
      const response = await axios.get('https://site.test/react/api/get_data.php');

      console.log('Fetched data:', response.data);
      setItems(response.data['post']);
    } catch (error) {
      console.error('Failed to fetch data:', error.message);
    }
  };
  return (
    <div>
      <h2>Comment</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="addPostID">Comment:</label>
          <input
            type="text"
            id="addPostID"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        <button type="submit">Submit</button>
      </form>
      <br/>
      <div>
      <h2>Items from API:</h2>
      {items.map((item, index) => (
        <div key={index}>
          <p>{item.uid}</p>
          <h3>{item.title}</h3>
        <form onSubmit={addComment}>
        <div>
          <label htmlFor={item.uid}>Comment:</label>
          <input
            type="text"
            id={item.uid}
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
        </div>
        <button type="submit">Submit</button>
      </form>
          {item.comment.map((it, ind) => (
        <div key={ind}>
          <p>{it.comment}</p>
        </div>
            ))}
        </div>
      ))}
    </div>
    </div>
  );
};

export default SubmitForm;