import React from 'react'
import './demo.css'
import { Redirect } from './redirect'
export const Demo = () => {
  return (
    <div className='container'>
        <div className='heading'>Its a heading</div>
        <button onClick={Redirect} data-test-id="my-btn">
        Click
      </button>
    </div>
  )
}
