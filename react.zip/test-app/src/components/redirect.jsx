import React from 'react'

export const Redirect = () => {
  return (
    <div className='big-text'>redirect</div>
  )
}
